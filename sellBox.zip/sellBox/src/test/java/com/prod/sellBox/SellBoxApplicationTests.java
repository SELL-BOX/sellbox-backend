package com.prod.sellBox;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SellBoxApplicationTests {

	@Test
	void contextLoads() {
	}

}
